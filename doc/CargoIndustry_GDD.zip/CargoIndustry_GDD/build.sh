#!/bin/sh
# Build the Cargo Industry Game Design Document. Requires XeLaTeX. Run twice.
xelatex -interaction=nonstopmode CargoIndustry_GDD.tex
xelatex -interaction=nonstopmode CargoIndustry_GDD.tex
