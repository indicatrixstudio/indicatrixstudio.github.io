# Cargo Industry — Game Design Document (A4, LaTeX)

Martin Timothy Timko · Indicatrix Studio
martin-timko@outlook.com · +421 944 645 449
https://store.steampowered.com/app/5155330/Cargo_Industry

Version 0.2 · September 2026 · 32 pages, A4

---

## What this document is

A GDD is a different animal from a pitch. The pitch persuades; the GDD
specifies. This document records the design of a game that already exists,
which means it is written as a record of implemented behaviour rather than as
a forward-looking plan.

**Version 0.2** incorporates the value analysis extracted from 19 project
source files. Construction costs, vehicle specifications, production and decay
rates, the wage formula, movement physics, the accounting cycle and the full
production chain are now documented with real numbers, and seven charts and a
production-graph diagram were added. It also adds a throughput analysis
section and five balance findings that fall out of the numbers.

It stays honest about its own gaps. Every value that lives in the code but is
not written down here is still marked.

## Visual design

White page, black text, with colour used only in bands and blocks — never a
full-page tint. Section headings sit in a navy band with white text,
subsections in a pale blue band with navy text. Callout boxes carry a coloured
left edge: blue for key points, amber for gaps, muted red for balance
findings. Charts use a navy-to-steel-blue range with a single gold accent.
Screenshots are framed in blue-grey.

## Two markers used throughout

| Marker | Meaning |
|---|---|
| `\tbd` → **[TBD]** | A value or rule that exists in the build but is not documented here — a cost, a rate, a capacity, a formula. Amber, so it cannot be skimmed past. |
| `\verify{...}` | A statement derived by inference rather than direct observation. Check it against the build before relying on it. |

Section 13 collects the questions that are genuinely still open, as opposed to
merely undocumented. Appendix B lists every gap in priority order.

## Contents

```
CargoIndustry_GDD.tex   The whole document
figures/                All images
build.sh                Two-pass XeLaTeX build script
README.md               This file
```

## How to build

Compile with **XeLaTeX, twice** — the second pass builds the table of contents
and resolves cross-references.

```
xelatex CargoIndustry_GDD.tex
xelatex CargoIndustry_GDD.tex
```

or `sh build.sh`, or `latexmk -xelatex CargoIndustry_GDD.tex`.

No fonts need installing. The document uses only the TeX Gyre family
(Pagella for body, Heros Cn for headings, Cursor for monospace), which ships
with every TeX Live and MiKTeX installation and is loaded by filename.

## Structure

1. Design overview — high concept, five design pillars, goals, non-goals, references
2. Core gameplay loop — the eight stages, with diagram
3. Game world — generation, terrain, cities, time
4. Construction systems — rail, road, placement rules
5. Industry and production — facility catalogue, resource catalogue, chains
6. Staff management — the core rule, professions, hiring and salary
7. Transport and fleet — depots, vehicles, routes, automatic rerouting
8. Economy — currency, revenue model, cost centres, statistics
9. User interface — HUD, panels, overlays, labels
10. Art direction and presentation
11. Audio
12. Technical specification, including development history
13. Open design questions
    Appendix A — interface reference (screenshots)
    Appendix B — completion checklist, gaps in priority order

## The four things worth filling in first

Appendix B has the full list, but these four define the game and everything
else is detail by comparison:

1. **The production chain matrix** (§5.1). Filling the Inputs and Outputs
   columns for all sixteen facilities defines the entire production graph, and
   with it the shape of every network a player can build. Nothing else in this
   document is worth as much.
2. **The revenue formula** (§8.2). How a delivery payment is calculated —
   whether distance, cargo type, quantity or time enters into it.
3. **What the three salary tiers actually do** (§6.3). If they differ only in
   cost, the selector is a tax rather than a decision.
4. **The role of cities** (§3.3). Whether a city is an economic actor or a
   named delivery point.

## Editing

The macros are the same family as the other two documents. `\tbd` and
`\tbdx{note}` for gaps, `\verify{note}` for inferences, `\begin{tbdbox}{amber}`
for a callout listing what is missing, `\begin{accentbox}{colour}` for a rule
worth emphasising, `\shot[width]{file}{caption}` for a framed screenshot.

Section numbering is on to three levels, and the table of contents shows two.
Change `\setcounter{tocdepth}{2}` if you want subsubsections listed.
