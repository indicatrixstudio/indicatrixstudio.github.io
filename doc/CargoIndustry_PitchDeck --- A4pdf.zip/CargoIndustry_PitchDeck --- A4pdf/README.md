# Cargo Industry — Publisher Pitch (A4 document version)

Martin Timothy Timko · Indicatrix Studio
martin-timko@outlook.com · +421 944 645 449
https://store.steampowered.com/app/5155330/Cargo_Industry

This is the **A4 document** version of the pitch: white paper, black text,
standard `article` class, 21 pages. It is meant to be read and printed, not
presented. The slide version (Beamer, 16:9, dark) is a separate package.

---

## Contents

```
CargoIndustry_PitchDocument.tex   The whole document
figures/                          All images
build.sh                          Two-pass XeLaTeX build script
README.md                         This file
```

## How to build

Compile with **XeLaTeX**, twice.

```
xelatex CargoIndustry_PitchDocument.tex
xelatex CargoIndustry_PitchDocument.tex
```

or `sh build.sh`, or `latexmk -xelatex CargoIndustry_PitchDocument.tex`.

**No fonts need to be installed.** Unlike the slide version, this document uses
only the TeX Gyre family, which ships with every TeX Live and MiKTeX
installation and is loaded by filename:

| Role | Font |
|---|---|
| Body | TeX Gyre Pagella (Palatino) — serif, made for continuous reading |
| Headings | TeX Gyre Heros Cn — condensed grotesque, same as the slide deck |
| Labels, dates, data | TeX Gyre Cursor — monospace |

If you prefer Poppins for headings (as in the deck), replace the `\newfontfamily\headfont`
line with `\newfontfamily\headfont{Poppins}` — but only if Poppins is installed
on the machine that compiles.

**Packages used:** fontspec, geometry, xcolor, graphicx, tcolorbox, titlesec,
enumitem, booktabs, array, fancyhdr, caption, tikz, microtype, hyperref. All
standard.

## Document structure

Title page, then sixteen numbered sections and an appendix:

1. Fact sheet (with rights status and design lineage)
2. Game overview
3. The core experience
4. Core gameplay loop (with diagram)
5. Gameplay systems
6. Unique selling points
7. World and setting
8. Art direction and visual identity
9. Target audience
10. Market positioning
11. Development status
12. Development history
13. Team and production approach
14. Business model
15. Roadmap and next steps
16. The ask (closing statement and contact block)
    Appendix — screenshot gallery, all ten screenshots at large size

The Steam URL appears on the title page in a bordered box, in the running
header of every page, and again in the contact block at the end. It is stored
once in the `\steamurl` macro.

## Editing

**Placeholders.** Everything unknown is wrapped in `\tba{...}` and prints in
amber, so it cannot be missed. Search for `TO BE ADDED`. Currently open:

- release window and price point (sections 1, 14, 15)
- comparable-title market data (section 10)
- location (section 13)
- wishlist and follower counts (section 9)

**Colours.** Defined once under `COLOURS`: `rail` (crimson), `indu` (green),
`amber` (placeholders), `linkc` (links), `ink` / `inkmute` (text), `rulec`
(hairlines), `panelbg` (light panel fill). All chosen to print cleanly.

**Boxes.** `\begin{keybox}` for a light grey callout, `\begin{accentbox}{colour}`
for a callout with a coloured edge, `\begin{steambox}` for the bordered link box.

**Images.** `\shot[width]{file}{caption}` places a framed, centred screenshot
with a caption. Default width is `\textwidth`.

**Margins.** Set in the `geometry` line at the top: 25 mm left and right,
24 mm top, 22 mm bottom.

## Before sending

1. Fix the Steam system requirements — they currently read **8 MB / 16 MB RAM**
   instead of GB, and storage jumps from 1000 MB to 20000 MB.
2. Fill the placeholders listed above, especially the wishlist count.
