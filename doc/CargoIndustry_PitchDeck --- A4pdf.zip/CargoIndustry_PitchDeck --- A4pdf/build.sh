#!/bin/sh
# Build the Cargo Industry A4 pitch document. Requires XeLaTeX. Run twice.
xelatex -interaction=nonstopmode CargoIndustry_PitchDocument.tex
xelatex -interaction=nonstopmode CargoIndustry_PitchDocument.tex
