#!/bin/sh
# Build the Cargo Industry pitch deck.
# Requires XeLaTeX (TeX Live / MiKTeX) — run twice for correct page references.
xelatex -interaction=nonstopmode CargoIndustry_PitchDeck.tex
xelatex -interaction=nonstopmode CargoIndustry_PitchDeck.tex
