# Cargo Industry — Publisher Pitch Deck (LaTeX / Beamer source)

Martin Timothy Timko · Indicatrix Studio
martin-timko@outlook.com · +421 944 645 449
https://store.steampowered.com/app/5155330/Cargo_Industry

---

## Contents

```
CargoIndustry_PitchDeck.tex   The whole deck (preamble + all 21 slides)
figures/                      All images used by the deck
build.sh                      Two-pass XeLaTeX build script
README.md                     This file
```

## How to build

The deck uses `fontspec`, so it must be compiled with **XeLaTeX** (not pdfLaTeX).
Run it twice so page numbers resolve.

```
xelatex CargoIndustry_PitchDeck.tex
xelatex CargoIndustry_PitchDeck.tex
```

or simply `sh build.sh`, or `latexmk -xelatex CargoIndustry_PitchDeck.tex`.

**Required packages:** beamer, fontspec, tikz, graphicx, xcolor, tcolorbox,
adjustbox, microtype, hyperref. All are in a standard TeX Live / MiKTeX
installation.

**Required fonts:** Poppins (body), TeX Gyre Heros Cn (headings), DejaVu Sans
Mono (labels and data). TeX Gyre and DejaVu ship with TeX Live. Poppins is a
free Google font — if it is missing, install it, or swap the two
`\setmainfont` / `\setsansfont` lines near the top of the `.tex` for any
installed sans face.

## Editing

Everything you are likely to change sits in clearly marked blocks.

**Placeholders.** Every unknown is wrapped in `\tba{...}` and renders in gold, so
missing information is visible rather than silently absent. Search the `.tex`
for `TO BE ADDED` / `TBA` to find them all. Currently outstanding:

- release window and price point (slides 2, 17)
- comparable-title market data (slide 13)
- location (slide 15)
- wishlist and follower counts (slide 12)

**Colours.** Defined once under `COLOUR SYSTEM`, derived from the game's own
palette: `rail` (crimson, construction UI), `indu` (green, industry and staff
UI), `gold` (credits and placeholders), `steamblue`, `ink`, `inkmute`, `bgdeep`.

**Type scale.** `\lead`, `\bodys`, `\bodyxs`, `\lbl`, `\eyeb` under
`TYPOGRAPHY`. Changing these sizes changes the whole deck at once — but note
that the slides are laid out close to the available height, so increasing a
size may push content under the footer. Check the log for
`Overfull \vbox` warnings after any change.

**Blocks.** `\begin{panel}`, `\begin{panelalt}` and
`\begin{apanel}{colour}{HEADING}` are the three panel styles.
`\chip{colour}{text}` and `\chipo{colour}{text}` are the small tags.
`\shotcap{LABEL}{caption}` is the caption line under a screenshot.

## Slide order (21 pages)

| # | Slide |
|---|---|
| 1 | Cover — with the Steam link as a full-width highlighted bar |
| 2 | Fact sheet — Steam link repeated, rights status, key data |
| 3 | Game overview |
| 4 | The core experience |
| 5 | Core gameplay loop (diagram) |
| 6 | Gameplay systems |
| 7 | Unique selling points 1 of 2 |
| 8 | Unique selling points 2 of 2 |
| 9 | World & setting |
| 10 | Art direction & visual identity |
| 11 | Screenshot showcase |
| 12 | Target audience |
| 13 | Market positioning |
| 14 | Development status |
| 15 | Team & production approach |
| 16 | Development history |
| 17 | Business model & roadmap |
| 18 | The ask |
| 19 | Closing — Steam link and contact |
| 20 | Appendix — screenshot gallery 1 of 2 |
| 21 | Appendix — screenshot gallery 2 of 2 |

The Steam URL also appears as a clickable link in the footer of every
numbered slide, and is stored once in the `\steamurl` macro.

## Figures

| File | Source | Notes |
|---|---|---|
| `hero.jpg` | Screenshot 08 | Cropped to clean 16:9, HUD removed — cover |
| `closing.jpg` | Screenshot 02 | Cropped to clean 16:9, HUD removed — closing |
| `world_env.jpg` | Screenshot 10 | Map edge cropped out |
| `world_city.jpg` | Screenshot 07 | Map edge cropped out (spare, currently unused) |
| `det_ui.jpg` | Screenshot 01 | Detail — UI panel |
| `det_staff.jpg` | Screenshot 05 | Detail — staff screen |
| `det_map.jpg` | Screenshot 06 | Detail — map overlay |
| `det_rail.jpg` | Screenshot 04 | Detail — rail junction |
| `shot01`–`shot10` | Screenshots 1–10 | Full frames, resized to 1600 px wide |

To swap in higher-resolution captures, replace the file in `figures/` keeping
the same filename and aspect ratio, then rebuild.

## Still to do before sending

1. Fix the Steam system requirements — they currently read **8 MB / 16 MB RAM**
   instead of GB, and storage jumps from 1000 MB to 20000 MB.
2. Fill the placeholders listed above, especially the wishlist count.
3. Produce a trailer. A finished game with no video is the most conspicuous
   gap in the package.
